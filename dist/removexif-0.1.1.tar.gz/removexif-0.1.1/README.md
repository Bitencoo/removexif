# removexif
Python package to easily add and remove metadata from images